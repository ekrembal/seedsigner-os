from setuptools import setup, find_namespace_packages

setup()
